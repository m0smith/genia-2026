# Slice A raw verification packet

Repository: m0smith/genia-2026, PR #1260, issue #1250.
Evidence/handoff commit: 7e4c0cb7d6a16aa4544688c341d90eeb0050171f.
Frozen source/truth-doc commit: 08a92c010ccef8b95fd67022622d41356bd1a749.
The commit attaching this ZIP changes process evidence only.

Read handoff/truth-audit-handoff.md and handoff/verification.md first.
This packet exports the committed handoffs, original review handoff, exact
closeout commit list/patch, actual raw test logs and scratch diagnostic helpers.
The patch ends at the evidence commit above, before this archive attachment.
SHA256SUMS hashes every other member. It is an evidence export, not production
code or a new conformance/protocol format.

All six frozen-source CI workflows passed. The local full non-loopback run
FAILED (7026 pass / 63 skip / 22 fail); it is not a full regression PASS.
A task-cache/network-permitted bounded MCP rerun produced 20 pass / 1 fail.
The unchanged two-launch cleanup assertion still saw a PID-1-adopted zombie
locally; the same case passed in CI. Assertions/timeouts were not weakened.
The task-only uv wrapper changes only its cache directory and execs the real
binary; it is not a replacement MCP implementation or a repository launcher fix.

Shared R16 869/869, focused 258 pass, final docs 518 pass / 35 skip, final
serial loopback 31 pass. C++ selected cases 5 PASS / 33 UNSUPPORTED, ancestor
contract pin, not current conformance/parity. Full findings, owners, removal
conditions and limitations are preserved in the handoffs. Independent truth
audit remains unperformed. PR is draft/unmerged; no Slice B work began.
