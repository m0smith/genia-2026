"""Observe process identities after the unchanged two-launch assertion fails.

This diagnostic invokes the original test function without altering its assertion,
waits or helpers. It prints only captured PIDs, process states and parent PIDs.
"""
from pathlib import Path
import json
import sys
from tests.unit.test_r28_mcp_conformance_lifecycle import (
    test_a_discover_probe_launch_followed_by_a_session_launch_leaves_nothing_behind as original,
)

try:
    original()
except AssertionError:
    trace = sys.exc_info()[2]
    while trace is not None:
        frame = trace.tb_frame
        if frame.f_code is original.__code__:
            states = []
            for pid, token in frame.f_locals.get('chain', set()):
                try:
                    content = Path(f'/proc/{pid}/stat').read_text()
                    rest = content[content.rfind(')') + 2:].split()
                    states.append({'pid': pid, 'state': rest[0], 'ppid': int(rest[1]),
                                   'same_start_token': str(token) == rest[19]})
                except FileNotFoundError:
                    states.append({'pid': pid, 'state': 'gone'})
            print('Captured chain states:', json.dumps(states), flush=True)
            print('PID 1 program:', Path('/proc/1/comm').read_text().strip(), flush=True)
        trace = trace.tb_next
    raise
print('Original assertion passed in this diagnostic invocation.')
