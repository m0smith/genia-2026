"""Rerun the failed MCP node IDs using the same uv-managed environment.

PATH carries an explicitly documented cache-only uv wrapper because the client
fixture intentionally drops UV_CACHE_DIR. Repository launchers/tests are intact.
"""
from pathlib import Path
import subprocess

nodes = [line.split()[1] for line in Path('work/non-loopback.log').read_text().splitlines()
         if line.startswith('FAILED tests/unit/test_r28_')]
print('Selected failing MCP cases:', len(nodes), flush=True)
raise SystemExit(subprocess.call([
    '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/uv',
    'run', '--no-sync', 'pytest', '-n0', '-q', *nodes,
]))
