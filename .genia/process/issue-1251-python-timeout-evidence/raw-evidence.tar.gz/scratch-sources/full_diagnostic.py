"""Run the single predeclared normal eight-worker full diagnostic with resource evidence."""
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT=Path('/workspace/work/1251/main');OUT=Path('/workspace/work/python-timeouts/evidence')
os.chdir(ROOT)
def counters():
    """Capture current quota/counter observations around the whole unchanged runner."""
    return {n:Path('/sys/fs/cgroup',n).read_text() for n in ['cpu.max','cpu.stat','memory.current','memory.events']}
command=[sys.executable,'-m','tools.spec_runner','--verbose','--host-jobs','8','--host',sys.executable+' -m hosts.python.protocol_adapter','--evidence',str(OUT/'full-diagnostic-python-evidence.json')]
record={'command':command,'before':counters(),'start_monotonic':time.monotonic(),'deadline':10,'unrelated_compilation_or_tests':False}
(OUT/'full-diagnostic-resource.json').write_text(json.dumps(record,indent=2))
before=resource.getrusage(resource.RUSAGE_CHILDREN)
with (OUT/'full-diagnostic-python.log').open('w') as stream:
    completed=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
after=resource.getrusage(resource.RUSAGE_CHILDREN)
record.update(exit_code=completed.returncode,wall_seconds=time.monotonic()-record['start_monotonic'],child_user=after.ru_utime-before.ru_utime,child_system=after.ru_stime-before.ru_stime,after=counters())
(OUT/'full-diagnostic-resource.json').write_text(json.dumps(record,indent=2)+'\n')
raise SystemExit(completed.returncode)
