"""Execute the frozen bounded acceptance once, retaining every outcome and failed stage."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import traceback

ROOT=Path('/workspace/work/python-timeouts/authority');OUT=Path('/workspace/work/python-timeouts/evidence/acceptance')
OUT.mkdir(exist_ok=True);os.chdir(ROOT);sys.path[:0]=[str(ROOT),str(ROOT/'src')]
from tools.spec_runner.loader import load_spec
from tools.spec_runner.host_executor import execute_spec_via_host
from tools.spec_runner.protocol import build_request,run_adapter_request
PY=sys.executable; CPP='/workspace/work/1251/cpp/build/genia-adapter'

def counters():
    """Record the measured resource envelope without changing limits or credentials."""
    return {n:Path('/sys/fs/cgroup',n).read_text() for n in ['cpu.max','cpu.stat','memory.max','memory.current','memory.events']}

def event(value):
    """Persist each acceptance boundary immediately; no failure is overwritten."""
    with (OUT/'events.jsonl').open('a') as stream:
        stream.write(json.dumps(value)+'\n');stream.flush();os.fsync(stream.fileno())

def full(host,command):
    """Execute exactly one complete canonical discovery with the original deadline."""
    args=[PY,'-m','tools.spec_runner','--verbose','--host-jobs','2','--host-timeout','10','--host',' '.join(command),'--evidence',str(OUT/(host+'-evidence.json'))]
    before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic();cg=counters()
    event({'event':'full_begin','host':host,'command':args,'before':cg})
    try:
        with (OUT/(host+'-full.log')).open('w') as stream:
            done=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
        result={'event':'full_end','host':host,'exit':done.returncode}
    except BaseException as exc:result={'event':'full_exception','host':host,'reason':repr(exc),'traceback':traceback.format_exc()}
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    result.update(wall=time.monotonic()-start,child_user=after.ru_utime-before.ru_utime,child_system=after.ru_stime-before.ru_stime,after=counters());event(result)

def one(host,command,spec,caps,index):
    """Retain one canonical comparison or exception at its preassigned index."""
    start=time.monotonic();event({'event':'request_begin','host':host,'case':spec.name,'index':index,'monotonic':start})
    try:
        result=execute_spec_via_host(spec,command,timeout=10.0,host_capabilities=caps)
        row={'kind':result.kind,'reason':result.reason,'failures':repr(result.failures)}
    except BaseException as exc:row={'kind':'exception','reason':repr(exc),'traceback':traceback.format_exc()}
    row.update(event='request_end',host=host,case=spec.name,index=index,wall=time.monotonic()-start);event(row);return row

def batch(host,command,case,count):
    """Run exactly the reserved count at two concurrent requests and save all classifications."""
    spec=load_spec(ROOT/'spec/eval'/case)
    caps=json.loads((OUT/(host+'-evidence.json')).read_text())['capabilities']
    start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);cg=counters();rows=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        pending={pool.submit(one,host,command,spec,caps,i):i for i in range(count)}
        for future in as_completed(pending):
            try:rows.append(future.result())
            except BaseException as exc:
                row={'host':host,'case':spec.name,'index':pending[future],'kind':'exception','reason':repr(exc)};event(row);rows.append(row)
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    record={'host':host,'case':spec.name,'samples':count,'concurrency':2,'deadline':10,'counts':dict(Counter(x['kind'] for x in rows)),'wall':time.monotonic()-start,'child_user':after.ru_utime-before.ru_utime,'child_system':after.ru_stime-before.ru_stime,'before':cg,'after':counters(),'results':sorted(rows,key=lambda x:x['index'])}
    (OUT/(host+'-'+spec.name+'.json')).write_text(json.dumps(record,indent=2)+'\n');event({k:v for k,v in record.items() if k!='results'})

def negative(host,command):
    """Verify exact existing postfailure rejection without changing host diagnostic differences."""
    source='p = spawn((msg) -> 1 / 0)\nsend(p, 1)\n_r25_await_idle()\nsend(p, 2)\nprint("unreachable")'
    expected='Error: send: process is failed\n' if host=='cpp' else 'Error: Process has failed: ZeroDivisionError: exact division by zero\n'
    try:
        actual=run_adapter_request(command,build_request('post-failure-send','eval',{'source':source,'stdin':None,'argv':None,'fixtures':['r25_concurrency']}),timeout=10.0)
        row={'event':'postfailure_negative','host':host,'kind':actual.kind,'result':actual.result,'pass':actual.kind=='ok' and actual.result=={'stdout':'','stderr':expected,'exit_code':1}}
    except BaseException as exc:row={'event':'postfailure_negative','host':host,'kind':'exception','pass':False,'reason':repr(exc)}
    event(row)

event({'event':'acceptance_begin','commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'python':sys.version,'cpp_source':subprocess.check_output(['git','-C','/workspace/work/1251/cpp','rev-parse','HEAD'],text=True).strip(),'cpp_binary_sha256':hashlib.sha256(Path(CPP).read_bytes()).hexdigest(),'no_competing_scheduled_tests_or_builds':True,'before':counters()})
for host,command in [('python',[PY,'-m','hosts.python.protocol_adapter']),('cpp',[CPP])]:full(host,command)
pair=[PY,'-m','tools.spec_runner.host_parity_gate','--python-evidence',str(OUT/'python-evidence.json'),'--cpp-evidence',str(OUT/'cpp-evidence.json'),'--known-gaps','spec/known_host_gaps.json']
with (OUT/'parity.log').open('w') as stream:result=subprocess.run(pair,stdout=stream,stderr=subprocess.STDOUT)
event({'event':'parity','exit':result.returncode})
batch('python',[PY,'-m','hosts.python.protocol_adapter'],'r25-process-fifo-fail-stop.yaml',200)
batch('cpp',[CPP],'r25-process-fifo-fail-stop.yaml',1000)
batch('python',[PY,'-m','hosts.python.protocol_adapter'],'r20-cross-module-view-mutual-tail-call.yaml',8)
negative('python',[PY,'-m','hosts.python.protocol_adapter']);negative('cpp',[CPP])
event({'event':'acceptance_end','after':counters()})
