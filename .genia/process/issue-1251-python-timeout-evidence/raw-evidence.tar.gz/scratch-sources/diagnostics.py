"""Finite infrastructure experiments using unchanged Genia transport and comparators."""
from __future__ import annotations
import concurrent.futures as cf
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import statistics
import subprocess
import sys
import time
import traceback

ROOT = Path('/workspace/work/1251/main')
OUT = Path('/workspace/work/python-timeouts/evidence')
PYTHON = '/workspace/genia-2026/.venv/bin/python'
sys.path[:0] = [str(ROOT), str(ROOT/'src')]
from tools.spec_runner.loader import load_spec
from tools.spec_runner.host_executor import execute_spec_via_host
from hosts.python.protocol_adapter import _python_claimed_capabilities

SPECS = {
    'r20': load_spec(ROOT/'spec/eval/r20-cross-module-view-mutual-tail-call.yaml'),
    'fixture': load_spec(ROOT/'spec/eval/r25-process-fifo-fail-stop.yaml'),
}
CAPS = _python_claimed_capabilities()

def snapshot():
    """Read nonsecret quota, memory and throttling observations without altering cgroups."""
    result = {}
    for name in ['cpu.max','cpu.stat','memory.max','memory.current','memory.events','pids.current']:
        path = Path('/sys/fs/cgroup')/name
        result[name] = path.read_text().strip() if path.exists() else None
    return result

def children():
    """Return this diagnostic supervisor's live/adopted direct child identities."""
    result = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            fields = (p/'stat').read_text().rsplit(')',1)[1].split()
            if int(fields[1]) == os.getpid():
                result.append({'pid':int(p.name),'state':fields[0], 'cpu_ticks':int(fields[11])+int(fields[12])})
        except (OSError, ValueError, IndexError): pass
    return result

def request(case, index):
    """Time one unchanged canonical request, including attributable reaped-child CPU."""
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    own = time.process_time(); start = time.monotonic()
    result = {'case':case,'index':index,'start_monotonic':start,'pid':os.getpid()}
    try:
        observed = execute_spec_via_host(SPECS[case], [PYTHON,'-m','hosts.python.protocol_adapter'],timeout=10.0,host_capabilities=CAPS)
        result.update(kind=observed.kind,reason=observed.reason,failures=repr(observed.failures))
    except BaseException as exc:
        result.update(kind='exception',reason=repr(exc),traceback=traceback.format_exc())
    end = resource.getrusage(resource.RUSAGE_CHILDREN)
    result.update(wall_seconds=time.monotonic()-start,worker_cpu_seconds=time.process_time()-own,
                  reaped_child_user_seconds=end.ru_utime-before.ru_utime,
                  reaped_child_system_seconds=end.ru_stime-before.ru_stime,
                  cpu_is_censored=result['kind'] in ['timeout','exception'])
    return result

def drain():
    """Observe then reap adopted exits; report any owned survivors before cleanup."""
    initial=children(); reaped=[]; stop=time.monotonic()+10
    while True:
        while True:
            try: pid,status,usage=os.wait4(-1,os.WNOHANG)
            except ChildProcessError: pid=0
            if not pid: break
            reaped.append({'pid':pid,'status':status,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime})
        live=children()
        if not live or time.monotonic()>=stop: break
        time.sleep(.05)
    survivors=children()
    for item in survivors:
        try: os.kill(item['pid'],9)
        except ProcessLookupError: pass
    for item in survivors:
        try: os.waitpid(item['pid'],0)
        except ChildProcessError: pass
    return {'initial_adopted':initial,'reaped':reaped,'survivors_at_observation_limit':survivors}

def batch(number, spec):
    """Execute exactly the frozen number of requests under one controlled condition."""
    before=snapshot(); started=time.monotonic(); burners=[]
    try:
        for _ in range(spec['burners']):
            p=subprocess.Popen([PYTHON,str(Path(__file__)),'--burn'],stdout=subprocess.PIPE,text=True)
            if p.stdout.readline().strip()!='ready': raise RuntimeError('burner readiness failed')
            burners.append(p)
        results=[]
        with cf.ProcessPoolExecutor(max_workers=spec['concurrency']) as pool:
            futures={pool.submit(request,spec['case'],i):i for i in range(spec['samples'])}
            for future in cf.as_completed(futures):
                try: results.append(future.result())
                except BaseException as exc:results.append({'index':futures[future],'kind':'exception','reason':repr(exc)})
    finally:
        for p in burners: p.terminate()
        for p in burners: p.wait()
    lifecycle=drain(); after=snapshot()
    results.sort(key=lambda x:x['index']); counts={}
    for item in results: counts[item['kind']]=counts.get(item['kind'],0)+1
    walls=sorted(x['wall_seconds'] for x in results if 'wall_seconds' in x)
    report={'batch':number,'plan':spec,'counts':counts,'wall_seconds':time.monotonic()-started,
            'request_wall':{'min':min(walls),'median':statistics.median(walls),'p95':walls[max(0,int(len(walls)*.95)-1)],'max':max(walls)},
            'before':before,'after':after,'lifecycle':lifecycle,'results':results}
    target=OUT/f'batch-{number:02d}-{spec["phase"]}-{spec["case"]}-c{spec["concurrency"]}.json'
    target.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['batch','plan','counts','request_wall']}),flush=True)

def main():
    """Run the predeclared matrix once and retain every batch before progressing."""
    if '--burn' in sys.argv:
        print('ready',flush=True); until=time.monotonic()+180; value=1
        while time.monotonic()<until:
            for _ in range(10000):value=(value*1664525+1013904223)&0xffffffff
        return
    os.chdir(ROOT)
    # Reap only exited descendants in the diagnostic supervisor, not in Genia.
    if ctypes.CDLL(None).prctl(36,1,0,0,0)!=0: raise OSError('subreaper setup failed')
    plan=json.loads((OUT/'experiment-plan.json').read_text())
    baseline={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
              'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
              'python':sys.version,'executable':sys.executable,'resources':snapshot(),
              'original_digests':json.loads((OUT/'original-evidence-digests.json').read_text()),
              'worker_mode':'separate diagnostic process per concurrency slot; canonical fresh adapter per request',
              'deadline':10,'supervisor_subreaper':True}
    (OUT/'baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
    for number,spec in enumerate(plan['batches']):batch(number,spec)

if __name__=='__main__':main()
