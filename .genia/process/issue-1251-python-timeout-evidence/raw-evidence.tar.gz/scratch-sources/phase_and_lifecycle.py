"""Run the frozen twelve startup probes and one bounded transport lifecycle probe."""
import ctypes
from dataclasses import replace
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT=Path('/workspace/work/1251/main'); BASE=Path('/workspace/work/python-timeouts'); OUT=BASE/'evidence'
sys.path[:0]=[str(ROOT),str(ROOT/'src')]
from tools.spec_runner.loader import load_spec
from tools.spec_runner.host_executor import execute_spec_via_host
from tools.spec_runner.protocol import build_request,run_adapter_request
from hosts.python.protocol_adapter import _python_claimed_capabilities
PY=sys.executable

def record(value):
    """Stream every completed/incomplete boundary before any subsequent experiment."""
    with (OUT/'phase-and-lifecycle.jsonl').open('a') as stream:
        stream.write(json.dumps(value)+'\n');stream.flush();os.fsync(stream.fileno())

def state(pid):
    """Observe a known owned PID without changing its lifecycle."""
    try:return Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[0]
    except FileNotFoundError:return 'gone'

os.chdir(ROOT)
if ctypes.CDLL(None).prctl(36,1,0,0,0)!=0:raise OSError('subreaper setup failed')
fixture=load_spec(ROOT/'spec/eval/r25-process-fifo-fail-stop.yaml')
r20=load_spec(ROOT/'spec/eval/r20-cross-module-view-mutual-tail-call.yaml')
arithmetic=replace(fixture,name='diagnostic-arithmetic',source='1',fixtures=(),requires=(),expected_stdout='1\n')
caps=_python_claimed_capabilities()
for label in ['capabilities','arithmetic','r20','fixture']:
    for index in range(3):
        path=OUT/f'profile-{label}-{index}.jsonl'
        start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
        record({'event':'probe_begin','case':label,'index':index,'monotonic':start,'deadline':10})
        try:
            command=[PY,str(BASE/'profile_adapter.py'),str(path)]
            if label=='capabilities':
                result=run_adapter_request(command,build_request('diagnostic-capabilities','capabilities',{}),timeout=10.0)
                observed={'kind':result.kind,'reason':result.reason}
            else:
                spec={'arithmetic':arithmetic,'r20':r20,'fixture':fixture}[label]
                result=execute_spec_via_host(spec,command,timeout=10.0,host_capabilities=caps)
                observed={'kind':result.kind,'reason':result.reason,'failures':repr(result.failures)}
        except BaseException as exc:observed={'kind':'exception','reason':repr(exc)}
        after=resource.getrusage(resource.RUSAGE_CHILDREN)
        record({'event':'probe_end','case':label,'index':index,'wall':time.monotonic()-start,'child_user':after.ru_utime-before.ru_utime,'child_system':after.ru_stime-before.ru_stime,**observed})

stub=BASE/'lifecycle_stub.py';pidfile=OUT/'lifecycle-child.json'
stub.write_text('import subprocess,sys,time,json,os\nfrom pathlib import Path\n'
    'p=subprocess.Popen([sys.executable,"-c","import time; time.sleep(15)"])\n'
    'Path(sys.argv[1]).write_text(json.dumps({"adapter_pid":os.getpid(),"child_pid":p.pid}))\n'
    'time.sleep(60)\n')
record({'event':'lifecycle_begin','deadline':10,'child_duration':15,'purpose':'synthetic infrastructure probe'})
start=time.monotonic()
try:
    result=run_adapter_request([PY,str(stub),str(pidfile)],build_request('diagnostic-lifecycle','eval',{'source':'1','stdin':None,'argv':None}),timeout=10.0)
    ids=json.loads(pidfile.read_text())
    record({'event':'lifecycle_timeout_return','wall':time.monotonic()-start,'kind':result.kind,'reason':result.reason,**ids,'adapter_state':state(ids['adapter_pid']),'child_state':state(ids['child_pid'])})
    pid,status,usage=os.wait4(ids['child_pid'],0)
    record({'event':'lifecycle_child_reaped','wall':time.monotonic()-start,'pid':pid,'status':status,'user':usage.ru_utime,'system':usage.ru_stime})
except BaseException as exc:record({'event':'lifecycle_exception','wall':time.monotonic()-start,'reason':repr(exc)})
