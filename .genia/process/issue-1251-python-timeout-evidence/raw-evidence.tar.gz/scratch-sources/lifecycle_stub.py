import subprocess,sys,time,json,os
from pathlib import Path
p=subprocess.Popen([sys.executable,"-c","import time; time.sleep(15)"])
Path(sys.argv[1]).write_text(json.dumps({"adapter_pid":os.getpid(),"child_pid":p.pid}))
time.sleep(60)
