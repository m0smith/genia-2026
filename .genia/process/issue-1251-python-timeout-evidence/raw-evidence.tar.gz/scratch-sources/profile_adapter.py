"""Record diagnostic phase timing while delegating unchanged adapter execution."""
import json
import resource
import sys
import time
from pathlib import Path

target = Path(sys.argv[1])
def event(kind, **fields):
    """Append one durable observation without writing to protocol stdout."""
    with target.open('a') as stream:
        stream.write(json.dumps({'event':kind,'monotonic':time.monotonic(),'own_cpu':time.process_time(),**fields})+'\n')
        stream.flush()

event('script_entry')
from hosts.python import protocol_adapter as adapter
event('adapter_imported')
original = adapter.run_case
def timed_case(spec):
    """Observe the existing host case boundary and retain its unchanged result."""
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    event('evaluation_begin')
    try:return original(spec)
    finally:
        after=resource.getrusage(resource.RUSAGE_CHILDREN)
        event('evaluation_end',child_user=after.ru_utime-before.ru_utime,child_system=after.ru_stime-before.ru_stime)
try:
    adapter.run_case=timed_case
    raise SystemExit(adapter.main())
finally:event('adapter_end')
